# Aver Web Interface

A Bootstrap 5-based web frontend for the Aver record management system, using PHP to communicate with `aver.py` via JSON IO mode.

## Features

- **User Management**: Configure user handle and email for record attribution
- **Template Support**: Select from available templates when creating records
- **Dynamic Forms**: Form fields automatically adjust based on selected template schema
- **Record Management**: Create, view, and search records
- **Notes**: Add notes to records with full user attribution
- **Real-time Updates**: Persistent connection to aver backend for fast operations
- **Bootstrap 5 UI**: Modern, responsive interface

## Requirements

- PHP 7.4 or higher
- aver.py installed and accessible
- Web server (Apache, Nginx, or PHP built-in server)
- Modern web browser

## Installation

### 1. Install aver.py

Make sure aver.py is installed and accessible in your system PATH:

```bash
# Test that aver is available
which aver
# or
aver --version
```

If aver is installed in a custom location, update the `AVER_PATH` constant in `api.php`:

```php
define('AVER_PATH', '/path/to/your/aver'); // Update this line
```

### 2. Deploy Web Files

Copy the web application files to your web server directory:

```bash
# For Apache on Ubuntu/Debian
sudo cp index.php api.php app.js /var/www/html/aver/

# For macOS with built-in Apache
sudo cp index.php api.php app.js /Library/WebServer/Documents/aver/
```

### 3. Configure Permissions

Ensure the web server can execute aver.py:

```bash
# If using Apache
sudo chown www-data:www-data /var/www/html/aver/*
sudo chmod 755 /var/www/html/aver/*
```

### 4. Configure aver

Make sure you have an aver database initialized:

```bash
# Initialize a new aver database
cd /path/to/your/project
aver admin init

# Or use an existing database
cd /path/to/existing/aver/project
```

The web application will use the aver database in the current working directory from which the web server runs aver.py.

### 5. Start the Web Server

#### Option A: PHP Built-in Server (Development)

```bash
cd /path/to/web/files
php -S localhost:8000
```

Then open http://localhost:8000 in your browser.

#### Option B: Apache/Nginx (Production)

Configure your web server to serve the directory containing the files.

Example Apache VirtualHost:

```apache
<VirtualHost *:80>
    ServerName aver.local
    DocumentRoot /var/www/html/aver
    
    <Directory /var/www/html/aver>
        AllowOverride All
        Require all granted
    </Directory>
    
    # Enable PHP processing
    <FilesMatch \.php$>
        SetHandler application/x-httpd-php
    </FilesMatch>
</VirtualHost>
```

## Initial Setup

### 1. Configure User Identity

On first access, you'll be prompted to set your user handle and email:

1. Click "User Settings" in the navigation bar
2. Enter your handle (username)
3. Enter your email address
4. Click "Save Settings"

These credentials will be used to attribute all records and notes you create.

### 2. Create Records

1. Click "Create Record" in the sidebar
2. Select a template (or use "Default")
3. Fill in the dynamically generated fields
4. Enter record content
5. Click "Create Record"

### 3. Search and View

- **All Records**: Click "All Records" to see recent records
- **Search**: Use the search form to filter by field values (e.g., `status=open`)
- **Details**: Click any record card to view full details and notes

## Configuration

### Customize aver Path

Edit `api.php` and change the `AVER_PATH` constant:

```php
define('AVER_PATH', '/usr/local/bin/aver'); // Change this
```

### Adjust Session Timeout

Edit `api.php` and change the `SESSION_TIMEOUT` constant:

```php
define('SESSION_TIMEOUT', 300); // Seconds (default: 5 minutes)
```

### Working Directory

By default, the web server will run aver from its current working directory. To specify a different aver database location, you can:

1. Set the working directory in your web server configuration
2. Modify `api.php` to change directory before starting aver:

```php
// In api.php, before proc_open:
chdir('/path/to/your/aver/database');
```

## Architecture

### Components

1. **index.php**: Main HTML interface with Bootstrap 5
2. **api.php**: PHP backend that communicates with aver.py via JSON IO
3. **app.js**: JavaScript frontend that handles UI interactions

### Data Flow

```
Browser → app.js → api.php → aver.py JSON IO → aver database
                           ←                  ←
```

### Key Features of JSON IO Integration

- **Persistent Connection**: `api.php` maintains a single process connection to `aver json io`
- **User Override**: Each request passes user identity from session to aver
- **Template Support**: Dynamic form generation based on template schemas
- **Real-time Communication**: Line-delimited JSON protocol for fast responses

## Troubleshooting

### "Failed to start aver process"

- Check that `AVER_PATH` in `api.php` points to correct aver location
- Verify web server has permission to execute aver
- Check that aver is executable: `chmod +x /path/to/aver`

### "No user configured" on first access

- This is normal - configure your user via the User Settings modal
- User settings are stored in PHP session

### Records not appearing

- Verify you're in a directory with an initialized aver database
- Check aver database location in `api.php`
- Run `aver record list` from command line to verify database accessibility

### Template dropdown empty

- Check that your aver database has templates configured in `config.toml`
- Default template should always appear
- Check browser console for JavaScript errors

### Permission errors

- Ensure web server user (www-data, apache, etc.) can read/write aver database
- Check file permissions: `ls -la /path/to/.aver`
- Verify git configuration if aver requires it

## Security Considerations

### Production Deployment

For production use, consider:

1. **Authentication**: Add proper user authentication (not just session-based handle/email)
2. **HTTPS**: Use SSL/TLS encryption
3. **Input Validation**: Add server-side validation beyond what aver provides
4. **Rate Limiting**: Prevent abuse of the API endpoints
5. **Access Control**: Restrict who can access the web interface
6. **Session Security**: Configure secure session settings in `php.ini`

### File Permissions

- Web files should be readable by web server but not writable
- Aver database directory needs write permissions for web server user
- Consider using a dedicated system user for the web application

## Development

### Adding New Features

To add new functionality:

1. **Backend**: Add new action handlers in `api.php`
2. **Frontend**: Add new functions in `app.js`
3. **UI**: Update `index.php` with new views/components

### Testing

Test aver connectivity manually:

```bash
# Test JSON IO mode
echo '{"command": "list-templates", "params": {}}' | aver json io
```

Test PHP API directly:

```bash
# List templates
curl "http://localhost:8000/api.php?action=list_templates"

# Search records
curl "http://localhost:8000/api.php?action=search_records&limit=5"
```

## License

This web interface follows the same license as aver.py.

## Support

For issues with:
- **aver.py**: Refer to aver documentation
- **Web interface**: Check this README and troubleshooting section
- **Templates/schemas**: Check aver config.toml documentation
