<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aver Record Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .record-card {
            transition: transform 0.2s;
        }
        .record-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .status-badge {
            font-size: 0.85rem;
            padding: 0.25rem 0.75rem;
        }
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
        }
        .sidebar {
            min-height: calc(100vh - 56px);
            background: #f8f9fa;
        }
        .nav-pills .nav-link {
            color: #495057;
        }
        .nav-pills .nav-link.active {
            background-color: #0d6efd;
        }
        .field-group {
            margin-bottom: 1rem;
        }
        .record-content {
            white-space: pre-wrap;
            font-family: monospace;
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 0.25rem;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-journal-check"></i> Aver Manager
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#userSettingsModal">
                            <i class="bi bi-person-circle"></i> User Settings
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar py-3">
                <ul class="nav nav-pills flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="#" onclick="showView('records'); return false;">
                            <i class="bi bi-list-ul"></i> All Records
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" onclick="showView('create'); return false;">
                            <i class="bi bi-plus-circle"></i> Create Record
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" onclick="showView('search'); return false;">
                            <i class="bi bi-search"></i> Search
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 py-3">
                <!-- Records List View -->
                <div id="recordsView" class="view-content">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h2>All Records</h2>
                        <button class="btn btn-primary" onclick="loadRecords()">
                            <i class="bi bi-arrow-clockwise"></i> Refresh
                        </button>
                    </div>
                    <div id="recordsList" class="row">
                        <!-- Records will be loaded here -->
                    </div>
                </div>

                <!-- Create Record View -->
                <div id="createView" class="view-content" style="display: none;">
                    <h2>Create New Record</h2>
                    <form id="createRecordForm" class="mt-3">
                        <div class="mb-3">
                            <label for="templateSelect" class="form-label">Template</label>
                            <select class="form-select" id="templateSelect" onchange="loadTemplateFields()">
                                <option value="">Loading templates...</option>
                            </select>
                        </div>
                        
                        <div id="dynamicFields">
                            <!-- Dynamic fields will be loaded here based on template -->
                        </div>

                        <div class="mb-3">
                            <label for="recordContent" class="form-label">Content</label>
                            <textarea class="form-control" id="recordContent" rows="8" required></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-plus-circle"></i> Create Record
                        </button>
                    </form>
                </div>

                <!-- Search View -->
                <div id="searchView" class="view-content" style="display: none;">
                    <h2>Search Records</h2>
                    <form id="searchForm" class="mt-3">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="searchQuery" class="form-label">Search Query</label>
                                <input type="text" class="form-control" id="searchQuery" 
                                       placeholder="e.g., status=open">
                                <small class="form-text text-muted">
                                    Format: field=value (e.g., status=open, priority=high)
                                </small>
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="searchLimit" class="form-label">Limit</label>
                                <input type="number" class="form-control" id="searchLimit" value="20" min="1" max="100">
                            </div>
                            <div class="col-md-3 mb-3">
                                <label class="form-label d-block">&nbsp;</label>
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="bi bi-search"></i> Search
                                </button>
                            </div>
                        </div>
                    </form>
                    <div id="searchResults" class="row mt-4">
                        <!-- Search results will appear here -->
                    </div>
                </div>

                <!-- Record Detail View -->
                <div id="detailView" class="view-content" style="display: none;">
                    <button class="btn btn-secondary mb-3" onclick="showView('records')">
                        <i class="bi bi-arrow-left"></i> Back to List
                    </button>
                    <div id="recordDetail">
                        <!-- Record details will be loaded here -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- User Settings Modal -->
    <div class="modal fade" id="userSettingsModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">User Settings</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="userSettingsForm">
                        <div class="mb-3">
                            <label for="userHandle" class="form-label">Handle</label>
                            <input type="text" class="form-control" id="userHandle" required>
                            <small class="form-text text-muted">Your username identifier</small>
                        </div>
                        <div class="mb-3">
                            <label for="userEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" id="userEmail" required>
                            <small class="form-text text-muted">Your email address</small>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="saveUserSettings()">Save Settings</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Container -->
    <div class="toast-container"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="app.js"></script>
</body>
</html>
