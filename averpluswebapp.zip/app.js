/**
 * Aver Frontend Application
 * Handles all client-side interactions with the PHP API backend
 */

// Global state
let currentUser = null;
let currentTemplates = [];
let currentTemplate = null;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

/**
 * Initialize the application
 */
async function initializeApp() {
    // Load user settings
    await loadUserSettings();
    
    // Load templates
    await loadTemplates();
    
    // Load initial records
    await loadRecords();
    
    // Set up form handlers
    setupFormHandlers();
    
    // Show user settings modal if not configured
    if (!currentUser) {
        const modal = new bootstrap.Modal(document.getElementById('userSettingsModal'));
        modal.show();
    }
}

/**
 * Load user settings from server
 */
async function loadUserSettings() {
    try {
        const response = await fetch('api.php?action=get_user');
        const result = await response.json();
        
        if (result.success) {
            currentUser = result.data;
            document.getElementById('userHandle').value = currentUser.handle;
            document.getElementById('userEmail').value = currentUser.email;
        }
    } catch (error) {
        console.error('Failed to load user settings:', error);
    }
}

/**
 * Save user settings
 */
async function saveUserSettings() {
    const handle = document.getElementById('userHandle').value.trim();
    const email = document.getElementById('userEmail').value.trim();
    
    if (!handle || !email) {
        showToast('Please enter both handle and email', 'warning');
        return;
    }
    
    try {
        const response = await fetch('api.php?action=set_user', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({handle, email})
        });
        
        const result = await response.json();
        
        if (result.success) {
            currentUser = result.data;
            showToast('User settings saved', 'success');
            
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('userSettingsModal'));
            modal.hide();
        } else {
            showToast('Failed to save settings: ' + result.error, 'danger');
        }
    } catch (error) {
        showToast('Error saving settings: ' + error.message, 'danger');
    }
}

/**
 * Load available templates
 */
async function loadTemplates() {
    try {
        const response = await fetch('api.php?action=list_templates');
        const result = await response.json();
        
        if (result.success) {
            currentTemplates = result.data.templates;
            
            // Populate template select
            const select = document.getElementById('templateSelect');
            select.innerHTML = currentTemplates.map(t => 
                `<option value="${t.id || ''}">${t.name}${t.description ? ' - ' + t.description : ''}</option>`
            ).join('');
            
            // Load fields for default template
            await loadTemplateFields();
        } else {
            showToast('Failed to load templates: ' + result.error, 'danger');
        }
    } catch (error) {
        showToast('Error loading templates: ' + error.message, 'danger');
    }
}

/**
 * Load fields for selected template
 */
async function loadTemplateFields() {
    const templateId = document.getElementById('templateSelect').value;
    
    try {
        const url = templateId 
            ? `api.php?action=schema_record&template=${encodeURIComponent(templateId)}`
            : 'api.php?action=schema_record';
            
        const response = await fetch(url);
        const result = await response.json();
        
        if (result.success) {
            const schema = result.data;
            renderTemplateFields(schema.fields);
        } else {
            showToast('Failed to load template schema: ' + result.error, 'danger');
        }
    } catch (error) {
        showToast('Error loading template fields: ' + error.message, 'danger');
    }
}

/**
 * Render dynamic fields based on template schema
 */
function renderTemplateFields(fields) {
    const container = document.getElementById('dynamicFields');
    container.innerHTML = '';
    
    for (const [fieldName, fieldDef] of Object.entries(fields)) {
        if (!fieldDef.editable) continue;
        
        const fieldGroup = document.createElement('div');
        fieldGroup.className = 'mb-3';
        
        const label = document.createElement('label');
        label.className = 'form-label';
        label.textContent = fieldName.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
        if (fieldDef.required) {
            label.innerHTML += ' <span class="text-danger">*</span>';
        }
        
        let input;
        
        if (fieldDef.accepted_values && fieldDef.accepted_values.length > 0) {
            // Dropdown for fields with accepted values
            input = document.createElement('select');
            input.className = 'form-select';
            input.id = `field_${fieldName}`;
            
            const emptyOption = document.createElement('option');
            emptyOption.value = '';
            emptyOption.textContent = '-- Select --';
            input.appendChild(emptyOption);
            
            fieldDef.accepted_values.forEach(value => {
                const option = document.createElement('option');
                option.value = value;
                option.textContent = value;
                if (fieldDef.default === value) {
                    option.selected = true;
                }
                input.appendChild(option);
            });
        } else if (fieldDef.value_type === 'integer' || fieldDef.value_type === 'float') {
            // Number input
            input = document.createElement('input');
            input.type = 'number';
            input.className = 'form-control';
            input.id = `field_${fieldName}`;
            if (fieldDef.value_type === 'float') {
                input.step = '0.01';
            }
            if (fieldDef.default !== undefined) {
                input.value = fieldDef.default;
            }
        } else {
            // Text input
            input = document.createElement('input');
            input.type = 'text';
            input.className = 'form-control';
            input.id = `field_${fieldName}`;
            if (fieldDef.default !== undefined) {
                input.value = fieldDef.default;
            }
        }
        
        if (fieldDef.required) {
            input.required = true;
        }
        
        fieldGroup.appendChild(label);
        fieldGroup.appendChild(input);
        container.appendChild(fieldGroup);
    }
}

/**
 * Load records from aver
 */
async function loadRecords(searchQuery = null, limit = 20) {
    try {
        let url = `api.php?action=search_records&limit=${limit}`;
        if (searchQuery) {
            url += `&ksearch=${encodeURIComponent(searchQuery)}`;
        }
        
        const response = await fetch(url);
        const result = await response.json();
        
        if (result.success) {
            renderRecords(result.data.records);
        } else {
            showToast('Failed to load records: ' + result.error, 'danger');
        }
    } catch (error) {
        showToast('Error loading records: ' + error.message, 'danger');
    }
}

/**
 * Render records in the list view
 */
function renderRecords(records) {
    const container = document.getElementById('recordsList');
    
    if (records.length === 0) {
        container.innerHTML = '<div class="col-12"><div class="alert alert-info">No records found</div></div>';
        return;
    }
    
    container.innerHTML = records.map(record => `
        <div class="col-md-6 col-lg-4 mb-3">
            <div class="card record-card h-100">
                <div class="card-body">
                    <h5 class="card-title">${escapeHtml(record.fields.title || record.id)}</h5>
                    ${record.fields.status ? 
                        `<span class="badge status-badge bg-${getStatusColor(record.fields.status)}">${record.fields.status}</span>` 
                        : ''}
                    <p class="card-text mt-2">${escapeHtml(truncate(record.content, 100))}</p>
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <small class="text-muted">${record.id}</small>
                        <button class="btn btn-sm btn-primary" onclick="viewRecord('${record.id}')">
                            View Details
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

/**
 * View record details
 */
async function viewRecord(recordId) {
    try {
        const response = await fetch(`api.php?action=get_record&record_id=${encodeURIComponent(recordId)}&include_notes=1`);
        const result = await response.json();
        
        if (result.success) {
            renderRecordDetail(result.data);
            showView('detail');
        } else {
            showToast('Failed to load record: ' + result.error, 'danger');
        }
    } catch (error) {
        showToast('Error loading record: ' + error.message, 'danger');
    }
}

/**
 * Render record detail view
 */
function renderRecordDetail(record) {
    const container = document.getElementById('recordDetail');
    
    const fieldsHtml = Object.entries(record.fields || {})
        .map(([key, value]) => `
            <div class="col-md-6 mb-2">
                <strong>${escapeHtml(key)}:</strong> 
                ${Array.isArray(value) ? value.map(v => escapeHtml(v)).join(', ') : escapeHtml(value)}
            </div>
        `).join('');
    
    const notesHtml = (record.notes || []).map(note => `
        <div class="card mb-2">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <h6 class="mb-0">${escapeHtml(note.id)}</h6>
                    <small class="text-muted">${escapeHtml(note.fields.timestamp || '')}</small>
                </div>
                ${note.fields.author ? `<small class="text-muted">by ${escapeHtml(note.fields.author)}</small>` : ''}
                <div class="record-content mt-2">${escapeHtml(note.content)}</div>
            </div>
        </div>
    `).join('');
    
    container.innerHTML = `
        <div class="card">
            <div class="card-header">
                <h3>${escapeHtml(record.fields.title || record.id)}</h3>
                ${record.fields.status ? 
                    `<span class="badge status-badge bg-${getStatusColor(record.fields.status)}">${record.fields.status}</span>` 
                    : ''}
            </div>
            <div class="card-body">
                <div class="row mb-3">
                    ${fieldsHtml}
                </div>
                <hr>
                <h5>Content</h5>
                <div class="record-content">${escapeHtml(record.content)}</div>
                
                ${record.notes && record.notes.length > 0 ? `
                    <hr>
                    <h5>Notes (${record.notes.length})</h5>
                    ${notesHtml}
                ` : ''}
                
                <hr>
                <button class="btn btn-primary" onclick="showAddNoteForm('${record.id}')">
                    <i class="bi bi-plus-circle"></i> Add Note
                </button>
            </div>
        </div>
        
        <div id="addNoteForm" style="display: none;" class="card mt-3">
            <div class="card-body">
                <h5>Add Note</h5>
                <form onsubmit="submitNote('${record.id}'); return false;">
                    <div class="mb-3">
                        <label for="noteContent" class="form-label">Note Content</label>
                        <textarea class="form-control" id="noteContent" rows="4" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Note</button>
                    <button type="button" class="btn btn-secondary" onclick="hideAddNoteForm()">Cancel</button>
                </form>
            </div>
        </div>
    `;
}

/**
 * Show add note form
 */
function showAddNoteForm(recordId) {
    document.getElementById('addNoteForm').style.display = 'block';
}

/**
 * Hide add note form
 */
function hideAddNoteForm() {
    document.getElementById('addNoteForm').style.display = 'none';
    document.getElementById('noteContent').value = '';
}

/**
 * Submit a note
 */
async function submitNote(recordId) {
    const content = document.getElementById('noteContent').value.trim();
    
    if (!content) {
        showToast('Please enter note content', 'warning');
        return;
    }
    
    try {
        const response = await fetch('api.php?action=add_note', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                record_id: recordId,
                content: content
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showToast('Note added successfully', 'success');
            hideAddNoteForm();
            // Reload record to show new note
            viewRecord(recordId);
        } else {
            showToast('Failed to add note: ' + result.error, 'danger');
        }
    } catch (error) {
        showToast('Error adding note: ' + error.message, 'danger');
    }
}

/**
 * Setup form handlers
 */
function setupFormHandlers() {
    // Create record form
    document.getElementById('createRecordForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const content = document.getElementById('recordContent').value.trim();
        const templateId = document.getElementById('templateSelect').value;
        
        if (!content) {
            showToast('Please enter record content', 'warning');
            return;
        }
        
        // Collect field values
        const fields = {};
        const dynamicFields = document.querySelectorAll('#dynamicFields input, #dynamicFields select');
        dynamicFields.forEach(field => {
            const fieldName = field.id.replace('field_', '');
            if (field.value) {
                fields[fieldName] = field.value;
            }
        });
        
        try {
            const payload = {
                content: content,
                fields: fields
            };
            
            if (templateId) {
                payload.template = templateId;
            }
            
            const response = await fetch('api.php?action=create_record', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload)
            });
            
            const result = await response.json();
            
            if (result.success) {
                showToast('Record created: ' + result.data.record_id, 'success');
                
                // Reset form
                document.getElementById('createRecordForm').reset();
                
                // Reload records and switch to list view
                await loadRecords();
                showView('records');
            } else {
                showToast('Failed to create record: ' + result.error, 'danger');
            }
        } catch (error) {
            showToast('Error creating record: ' + error.message, 'danger');
        }
    });
    
    // Search form
    document.getElementById('searchForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const query = document.getElementById('searchQuery').value.trim();
        const limit = parseInt(document.getElementById('searchLimit').value);
        
        try {
            let url = `api.php?action=search_records&limit=${limit}`;
            if (query) {
                url += `&ksearch=${encodeURIComponent(query)}`;
            }
            
            const response = await fetch(url);
            const result = await response.json();
            
            if (result.success) {
                const container = document.getElementById('searchResults');
                if (result.data.records.length === 0) {
                    container.innerHTML = '<div class="col-12"><div class="alert alert-info">No records found</div></div>';
                } else {
                    container.innerHTML = result.data.records.map(record => `
                        <div class="col-md-6 col-lg-4 mb-3">
                            <div class="card record-card h-100">
                                <div class="card-body">
                                    <h5 class="card-title">${escapeHtml(record.fields.title || record.id)}</h5>
                                    ${record.fields.status ? 
                                        `<span class="badge status-badge bg-${getStatusColor(record.fields.status)}">${record.fields.status}</span>` 
                                        : ''}
                                    <p class="card-text mt-2">${escapeHtml(truncate(record.content, 100))}</p>
                                    <div class="d-flex justify-content-between align-items-center mt-3">
                                        <small class="text-muted">${record.id}</small>
                                        <button class="btn btn-sm btn-primary" onclick="viewRecord('${record.id}')">
                                            View Details
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `).join('');
                }
            } else {
                showToast('Search failed: ' + result.error, 'danger');
            }
        } catch (error) {
            showToast('Search error: ' + error.message, 'danger');
        }
    });
}

/**
 * Show a specific view
 */
function showView(viewName) {
    // Hide all views
    document.querySelectorAll('.view-content').forEach(view => {
        view.style.display = 'none';
    });
    
    // Update nav
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    
    // Show selected view
    const viewMap = {
        'records': 'recordsView',
        'create': 'createView',
        'search': 'searchView',
        'detail': 'detailView'
    };
    
    document.getElementById(viewMap[viewName]).style.display = 'block';
    
    // Update active nav link
    if (viewName !== 'detail') {
        const navLinks = document.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            if (link.textContent.toLowerCase().includes(viewName)) {
                link.classList.add('active');
            }
        });
    }
}

/**
 * Show toast notification
 */
function showToast(message, type = 'info') {
    const toastContainer = document.querySelector('.toast-container');
    const toastId = 'toast_' + Date.now();
    
    const toastHtml = `
        <div id="${toastId}" class="toast align-items-center text-white bg-${type} border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body">${escapeHtml(message)}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    `;
    
    toastContainer.insertAdjacentHTML('beforeend', toastHtml);
    
    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, {autohide: true, delay: 3000});
    toast.show();
    
    // Remove element after it's hidden
    toastElement.addEventListener('hidden.bs.toast', () => {
        toastElement.remove();
    });
}

/**
 * Utility: Escape HTML
 */
function escapeHtml(text) {
    if (typeof text !== 'string') {
        text = String(text);
    }
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}

/**
 * Utility: Truncate text
 */
function truncate(text, maxLength) {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
}

/**
 * Utility: Get status color
 */
function getStatusColor(status) {
    const colors = {
        'open': 'primary',
        'in_progress': 'warning',
        'resolved': 'success',
        'closed': 'secondary',
        'pending': 'info'
    };
    return colors[status] || 'secondary';
}
