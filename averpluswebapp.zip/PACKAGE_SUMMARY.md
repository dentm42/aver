# Aver Web Interface - Complete Package

## Summary

This package provides a complete web-based frontend for the Aver record management system, built with PHP, Bootstrap 5, and JavaScript. It communicates with aver.py via the JSON IO mode for high-performance operations.

## What's Included

### 1. Updated aver.py
**File:** `aver.py`

**Changes:**
- **Fixed recursion bug** in `get_manager_with_override()` (line 9311)
- **Enhanced `_setup_write_command()`** to support user identity overrides from JSON IO
- **Added `list-templates` command** to JSON IO mode for retrieving available templates
- **Fixed user override handling** in `import-record`, `import-note`, and `update-record` commands

The updated aver.py includes all bug fixes from the earlier debugging session plus the new template listing functionality.

### 2. Web Application Files

#### index.php
The main HTML interface featuring:
- Bootstrap 5 responsive design
- Navigation sidebar with views for Records, Create, and Search
- User settings modal for configuring handle and email
- Dynamic form generation based on template schemas
- Record detail view with notes
- Toast notifications for user feedback

#### api.php
The PHP backend that:
- Maintains persistent connection to `aver json io`
- Handles all API requests from the frontend
- Manages user identity via PHP sessions
- Provides endpoints for all aver operations
- Includes error handling and timeout management

#### app.js
The JavaScript frontend that:
- Handles all user interactions
- Makes AJAX calls to api.php
- Dynamically generates forms based on template schemas
- Renders records, search results, and details
- Manages application state and navigation

### 3. Documentation

#### README_WEB_INTERFACE.md
Complete setup and usage guide covering:
- Installation requirements
- Deployment instructions for various web servers
- Configuration options
- Troubleshooting common issues
- Security considerations
- Development guidelines

#### JSON_IO_MODE_GUIDE.md (Updated)
Updated developer guide with:
- Complete documentation of all JSON IO commands
- **NEW:** `list-templates` command documentation
- Integration examples in multiple languages
- Protocol specifications
- User identity override feature

#### FIXES_SUMMARY.md
Technical documentation of all bug fixes applied to aver.py

#### example_config.toml
Example aver configuration demonstrating:
- Template definitions
- Special field configurations
- Different template types (bug_report, feature_request, customer_issue)

## Key Features

### Template System
- **Dynamic Template Selection:** Users can choose from available templates when creating records
- **Schema-Driven Forms:** Form fields automatically adjust based on template configuration
- **Template Discovery:** New `list-templates` command provides template metadata

### User Management
- **Session-Based Identity:** Handle and email stored in PHP session
- **User Override Support:** Each request passes user identity to aver
- **Easy Configuration:** Simple modal interface for setting user credentials

### Performance
- **Persistent Connections:** Single aver process handles multiple requests
- **JSON IO Protocol:** Line-delimited JSON for fast communication
- **Connection Pooling Ready:** Architecture supports scaling to multiple connections

### User Interface
- **Modern Design:** Bootstrap 5 with responsive layouts
- **Intuitive Navigation:** Sidebar navigation with clear view separation
- **Rich Cards:** Record cards with status badges and quick actions
- **Detail Views:** Full record information including notes
- **Toast Notifications:** Non-intrusive feedback for all operations

## New JSON IO Command: list-templates

### Purpose
Allows frontend applications to discover available templates and their metadata without parsing config files.

### Request
```json
{"command": "list-templates", "params": {}}
```

### Response
```json
{
  "success": true,
  "result": {
    "templates": [
      {
        "id": null,
        "name": "Default",
        "description": "Default record with standard fields"
      },
      {
        "id": "bug_report",
        "name": "bug_report",
        "description": "Prefix: BUG, 5 custom field(s)"
      }
    ]
  }
}
```

### Implementation Details
- Always includes "Default" template (id: null)
- Automatically extracts template metadata from config
- Generates descriptions based on template characteristics
- Used by frontend to populate template selection dropdown

## Quick Start

### 1. Install Files
```bash
# Copy web files to your web directory
cp index.php api.php app.js /var/www/html/aver/

# Copy updated aver.py to replace your existing installation
sudo cp aver.py /usr/local/bin/aver
sudo chmod +x /usr/local/bin/aver
```

### 2. Configure aver
```bash
# Initialize or navigate to your aver database
cd /path/to/your/project
aver admin init

# Optionally copy the example config
cp example_config.toml .aver/config.toml
```

### 3. Update api.php
Edit `api.php` and set the correct aver path:
```php
define('AVER_PATH', '/usr/local/bin/aver'); // Update if needed
```

### 4. Start the Server
```bash
# For development
cd /var/www/html/aver
php -S localhost:8000

# For production, configure Apache/Nginx
```

### 5. Open in Browser
Navigate to http://localhost:8000

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                      Web Browser                         │
│                                                          │
│  ┌────────────┐  ┌──────────────┐  ┌────────────────┐ │
│  │ index.php  │  │   app.js     │  │ Bootstrap 5 UI│ │
│  │  (HTML)    │  │ (Frontend)   │  │                │ │
│  └────────────┘  └──────────────┘  └────────────────┘ │
└───────────────────────┬─────────────────────────────────┘
                        │ AJAX (fetch)
                        ▼
┌─────────────────────────────────────────────────────────┐
│                     Web Server (PHP)                     │
│                                                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │              api.php (Backend)                    │  │
│  │  - Session management                             │  │
│  │  - User identity handling                         │  │
│  │  - Process management                             │  │
│  └──────────────┬───────────────────────────────────┘  │
└─────────────────┼───────────────────────────────────────┘
                  │ proc_open + JSON IO
                  ▼
┌─────────────────────────────────────────────────────────┐
│              aver json io (Python Process)              │
│                                                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │  Command Router                                   │  │
│  │  - list-templates (NEW)                          │  │
│  │  - schema-record                                 │  │
│  │  - import-record                                 │  │
│  │  - export-record                                 │  │
│  │  - search-records                                │  │
│  │  - etc.                                          │  │
│  └──────────────┬───────────────────────────────────┘  │
└─────────────────┼───────────────────────────────────────┘
                  │
                  ▼
┌─────────────────────────────────────────────────────────┐
│           Aver Database (.aver/)                        │
│  - SQLite index                                         │
│  - Markdown files                                       │
│  - config.toml                                          │
└─────────────────────────────────────────────────────────┘
```

## Testing the Installation

### Test aver.py directly
```bash
# Test the new list-templates command
echo '{"command": "list-templates", "params": {}}' | aver json io

# Should output:
# {"success": true, "result": {"templates": [...]}}
```

### Test the web interface
1. Open http://localhost:8000
2. Set your user credentials in User Settings
3. Click "Create Record"
4. Verify templates appear in dropdown
5. Select a template and verify fields change
6. Create a test record
7. View the record in the list

### Verify bug fixes
```bash
# Test that recursion bug is fixed
echo '{"command": "export-record", "params": {"record_id": "REC-XXX"}}' | aver json io

# Should return valid JSON, not recursion error
```

## Files Summary

| File | Purpose | Lines |
|------|---------|-------|
| aver.py | Updated backend with fixes + new command | ~9900 |
| index.php | Main web interface HTML | ~220 |
| api.php | PHP backend API | ~370 |
| app.js | JavaScript frontend logic | ~580 |
| README_WEB_INTERFACE.md | Setup and usage guide | ~400 |
| JSON_IO_MODE_GUIDE.md | Updated API documentation | ~570 |
| example_config.toml | Example template configuration | ~150 |
| FIXES_SUMMARY.md | Bug fix documentation | ~150 |

## Next Steps

### Recommended Enhancements
1. **Authentication:** Add proper user authentication system
2. **Permissions:** Implement role-based access control
3. **File Uploads:** Support attachments on records
4. **Rich Text:** Add markdown editor for record content
5. **Filters:** Advanced filtering and sorting in search
6. **Exports:** PDF/CSV export functionality
7. **Dashboards:** Statistics and visualization views

### Production Deployment Checklist
- [ ] Configure HTTPS/SSL
- [ ] Set up proper authentication
- [ ] Configure session security settings
- [ ] Set appropriate file permissions
- [ ] Enable error logging
- [ ] Configure backup strategy
- [ ] Test with production data volume
- [ ] Set up monitoring

## Support

- For aver.py issues: Check aver documentation
- For web interface issues: See README_WEB_INTERFACE.md
- For JSON IO protocol: See JSON_IO_MODE_GUIDE.md
- For template configuration: See example_config.toml

## License

This web interface follows the same license as aver.py.
