<?php
/**
 * Aver JSON IO API Backend
 * 
 * This file provides a REST-like API that communicates with aver.py via JSON IO mode.
 * It maintains a persistent connection to aver for better performance.
 */

header('Content-Type: application/json');

// Configuration
define('AVER_PATH', '/usr/local/bin/aver'); // Adjust this path to your aver installation
define('SESSION_TIMEOUT', 300); // 5 minutes

session_start();

/**
 * AverClient - Manages communication with aver.py via JSON IO mode
 */
class AverClient {
    private $process;
    private $pipes;
    private $lastActivity;
    
    public function __construct() {
        $this->connect();
    }
    
    /**
     * Establish connection to aver json io
     */
    private function connect() {
        $descriptorspec = [
            0 => ["pipe", "r"],  // stdin
            1 => ["pipe", "w"],  // stdout
            2 => ["pipe", "w"]   // stderr
        ];
        
        $this->process = proc_open(AVER_PATH . ' json io', $descriptorspec, $this->pipes);
        
        if (!is_resource($this->process)) {
            throw new Exception("Failed to start aver process");
        }
        
        // Set pipes to non-blocking mode
        stream_set_blocking($this->pipes[1], false);
        stream_set_blocking($this->pipes[2], false);
        
        $this->lastActivity = time();
    }
    
    /**
     * Execute a command via JSON IO
     */
    public function execute($command, $params = [], $userId = null) {
        // Check if connection is stale
        if (time() - $this->lastActivity > SESSION_TIMEOUT) {
            $this->close();
            $this->connect();
        }
        
        $request = [
            'command' => $command,
            'params' => $params
        ];
        
        if ($userId !== null) {
            $request['id'] = $userId;
        }
        
        // Send request
        $jsonRequest = json_encode($request) . "\n";
        fwrite($this->pipes[0], $jsonRequest);
        fflush($this->pipes[0]);
        
        // Read response
        $response = '';
        $timeout = 10; // 10 second timeout
        $start = microtime(true);
        
        while (microtime(true) - $start < $timeout) {
            $line = fgets($this->pipes[1]);
            if ($line !== false) {
                $response = trim($line);
                break;
            }
            usleep(10000); // Sleep 10ms
        }
        
        if (empty($response)) {
            // Check for errors on stderr
            $error = stream_get_contents($this->pipes[2]);
            throw new Exception("No response from aver" . ($error ? ": $error" : ""));
        }
        
        $this->lastActivity = time();
        
        $result = json_decode($response, true);
        if ($result === null) {
            throw new Exception("Invalid JSON response: $response");
        }
        
        return $result;
    }
    
    /**
     * Close the connection
     */
    public function close() {
        if (is_resource($this->process)) {
            fwrite($this->pipes[0], "\n"); // Send empty line to exit
            fclose($this->pipes[0]);
            fclose($this->pipes[1]);
            fclose($this->pipes[2]);
            proc_close($this->process);
        }
    }
    
    public function __destruct() {
        $this->close();
    }
}

/**
 * Get or create AverClient from session
 */
function getAverClient() {
    // Note: In production, you'd want a more robust connection pooling system
    // For this example, we create a new connection per request
    return new AverClient();
}

/**
 * Get user identity from session
 */
function getUserIdentity() {
    if (!isset($_SESSION['user_handle']) || !isset($_SESSION['user_email'])) {
        return null;
    }
    
    return [
        'handle' => $_SESSION['user_handle'],
        'email' => $_SESSION['user_email']
    ];
}

/**
 * Send JSON response
 */
function sendResponse($success, $data = null, $error = null) {
    echo json_encode([
        'success' => $success,
        'data' => $data,
        'error' => $error
    ]);
    exit;
}

// Handle CORS for local development
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Route the request
$action = $_GET['action'] ?? $_POST['action'] ?? null;

if (!$action) {
    sendResponse(false, null, "No action specified");
}

try {
    $client = getAverClient();
    $userId = getUserIdentity();
    
    switch ($action) {
        case 'list_templates':
            // Get list of available templates
            $result = $client->execute('list-templates', []);
            if ($result['success']) {
                sendResponse(true, $result['result']);
            } else {
                sendResponse(false, null, $result['error']);
            }
            break;
            
        case 'schema_record':
            // Get schema for a template
            $template = $_GET['template'] ?? $_POST['template'] ?? null;
            $params = $template ? ['template' => $template] : [];
            
            $result = $client->execute('schema-record', $params);
            if ($result['success']) {
                sendResponse(true, $result['result']);
            } else {
                sendResponse(false, null, $result['error']);
            }
            break;
            
        case 'search_records':
            // Search for records
            $ksearch = $_GET['ksearch'] ?? $_POST['ksearch'] ?? null;
            $limit = intval($_GET['limit'] ?? $_POST['limit'] ?? 20);
            
            $params = ['limit' => $limit];
            if ($ksearch) {
                $params['ksearch'] = $ksearch;
            }
            
            $result = $client->execute('search-records', $params, $userId);
            if ($result['success']) {
                sendResponse(true, $result['result']);
            } else {
                sendResponse(false, null, $result['error']);
            }
            break;
            
        case 'get_record':
            // Get a specific record
            $recordId = $_GET['record_id'] ?? $_POST['record_id'] ?? null;
            if (!$recordId) {
                sendResponse(false, null, "Missing record_id parameter");
            }
            
            $includeNotes = isset($_GET['include_notes']) || isset($_POST['include_notes']);
            
            $result = $client->execute('export-record', [
                'record_id' => $recordId,
                'include_notes' => $includeNotes
            ], $userId);
            
            if ($result['success']) {
                sendResponse(true, $result['result']);
            } else {
                sendResponse(false, null, $result['error']);
            }
            break;
            
        case 'create_record':
            // Create a new record
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($data['content'])) {
                sendResponse(false, null, "Missing content parameter");
            }
            
            $params = [
                'content' => $data['content'],
                'fields' => $data['fields'] ?? []
            ];
            
            if (isset($data['template'])) {
                $params['template'] = $data['template'];
            }
            
            $result = $client->execute('import-record', $params, $userId);
            
            if ($result['success']) {
                sendResponse(true, $result['result']);
            } else {
                sendResponse(false, null, $result['error']);
            }
            break;
            
        case 'update_record':
            // Update an existing record
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($data['record_id'])) {
                sendResponse(false, null, "Missing record_id parameter");
            }
            
            $params = [
                'record_id' => $data['record_id']
            ];
            
            if (isset($data['fields'])) {
                $params['fields'] = $data['fields'];
            }
            
            if (isset($data['content'])) {
                $params['content'] = $data['content'];
            }
            
            $result = $client->execute('update-record', $params, $userId);
            
            if ($result['success']) {
                sendResponse(true, $result['result']);
            } else {
                sendResponse(false, null, $result['error']);
            }
            break;
            
        case 'add_note':
            // Add a note to a record
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($data['record_id']) || !isset($data['content'])) {
                sendResponse(false, null, "Missing required parameters");
            }
            
            $params = [
                'record_id' => $data['record_id'],
                'content' => $data['content'],
                'fields' => $data['fields'] ?? []
            ];
            
            $result = $client->execute('import-note', $params, $userId);
            
            if ($result['success']) {
                sendResponse(true, $result['result']);
            } else {
                sendResponse(false, null, $result['error']);
            }
            break;
            
        case 'set_user':
            // Set user identity in session
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($data['handle']) || !isset($data['email'])) {
                sendResponse(false, null, "Missing handle or email");
            }
            
            $_SESSION['user_handle'] = $data['handle'];
            $_SESSION['user_email'] = $data['email'];
            
            sendResponse(true, [
                'handle' => $data['handle'],
                'email' => $data['email']
            ]);
            break;
            
        case 'get_user':
            // Get current user identity
            $user = getUserIdentity();
            if ($user) {
                sendResponse(true, $user);
            } else {
                sendResponse(false, null, "No user configured");
            }
            break;
            
        default:
            sendResponse(false, null, "Unknown action: $action");
    }
    
} catch (Exception $e) {
    sendResponse(false, null, $e->getMessage());
}
