# 🚀 Aver Docker Quick Start

Get up and running with Aver in under 2 minutes!

## Prerequisites

- Docker installed ([Get Docker](https://docs.docker.com/get-docker/))
- Docker Compose installed (included with Docker Desktop)

## Installation

### 1️⃣ Download Files

```bash
# Create project directory
mkdir aver-docker
cd aver-docker

# Copy these files to the directory:
# - Dockerfile
# - docker-compose.yml
# - index.php
# - api.php
# - app.js
# - aver.py
# - init-aver.sh
# - .dockerignore
```

### 2️⃣ Start Aver

**Using Make (Recommended):**
```bash
make up
```

**Or using Docker Compose:**
```bash
docker-compose up -d
```

### 3️⃣ Access the Interface

Open your browser to: **http://localhost:8080**

### 4️⃣ Configure Your User

1. Click **"User Settings"** in the top navigation
2. Enter your **handle** (e.g., `john.doe`)
3. Enter your **email** (e.g., `john@example.com`)
4. Click **"Save Settings"**

### 5️⃣ Create Your First Record

1. Click **"Create Record"** in the sidebar
2. Select a template (try "bug_report")
3. Fill in the fields
4. Enter content
5. Click **"Create Record"**

🎉 **That's it!** You're now running Aver.

## Common Commands

```bash
# View logs
make logs
# or: docker-compose logs -f

# Access container shell
make shell
# or: docker exec -it aver-web bash

# Restart
make restart
# or: docker-compose restart

# Stop
make down
# or: docker-compose down

# Backup data
make backup

# View all commands
make help
```

## What's Running?

- **Web Interface**: http://localhost:8080
- **Container Name**: `aver-web`
- **Data Location**: Docker volume `aver-data`
- **Database**: Auto-initialized on first start

## Accessing Your Data

### View Database Files
```bash
docker exec aver-web ls -la /data/.aver
```

### Use Aver CLI
```bash
docker exec -it aver-web bash
cd /data
aver record list
aver record show REC-XXX
```

### Backup to Local File
```bash
docker run --rm \
  -v aver-web_aver-data:/data \
  -v $(pwd):/backup \
  ubuntu tar czf /backup/my-backup.tar.gz /data
```

## Customization

### Change Port
Edit `docker-compose.yml`:
```yaml
ports:
  - "3000:80"  # Now accessible at http://localhost:3000
```

### Use Local Directory for Data
Edit `docker-compose.yml`:
```yaml
volumes:
  - ./my-data:/data  # Data now in ./my-data directory
```

### Custom Configuration
Create your own config at `./my-data/.aver/config.toml` after first start

## Troubleshooting

**Port 8080 already in use?**
```bash
# Use different port
docker-compose down
# Edit docker-compose.yml, change 8080 to another port
docker-compose up -d
```

**Container won't start?**
```bash
# Check logs
docker-compose logs

# Common fix: remove old containers
docker-compose down
docker-compose up -d
```

**Need to reset everything?**
```bash
# WARNING: This deletes all data!
docker-compose down -v
docker-compose up -d
```

## Next Steps

- 📖 Read [DOCKER_README.md](DOCKER_README.md) for detailed documentation
- 🔧 Customize templates in `/data/.aver/config.toml`
- 🔐 Set up HTTPS for production use
- 📊 Explore the API at [JSON_IO_MODE_GUIDE.md](JSON_IO_MODE_GUIDE.md)

## Architecture

```
┌─────────────────────────────────┐
│   Browser (localhost:8080)      │
└────────────┬────────────────────┘
             │ HTTP
             ▼
┌─────────────────────────────────┐
│    Docker Container (aver-web)  │
│  ┌──────────────────────────┐  │
│  │  Apache + PHP            │  │
│  │  - index.php             │  │
│  │  - api.php               │  │
│  │  - app.js                │  │
│  └──────────┬───────────────┘  │
│             │ JSON IO          │
│             ▼                  │
│  ┌──────────────────────────┐  │
│  │  aver.py (Python)        │  │
│  └──────────┬───────────────┘  │
│             │                  │
│             ▼                  │
│  ┌──────────────────────────┐  │
│  │  /data/.aver/            │  │
│  │  - db.sqlite             │  │
│  │  - records/*.md          │  │
│  │  - config.toml           │  │
│  └──────────────────────────┘  │
└─────────────┬───────────────────┘
              │
              ▼
┌─────────────────────────────────┐
│   Docker Volume (aver-data)     │
│   Persists between restarts     │
└─────────────────────────────────┘
```

## Production Checklist

Before deploying to production:

- [ ] Change default port or use reverse proxy
- [ ] Set up HTTPS/SSL
- [ ] Configure authentication
- [ ] Set up regular backups
- [ ] Configure monitoring
- [ ] Review security settings
- [ ] Set resource limits
- [ ] Configure logging

See [DOCKER_README.md](DOCKER_README.md) for production deployment details.

## Support

- 🐛 **Issues**: Check logs with `make logs`
- 📚 **Documentation**: See included markdown files
- 🔧 **Configuration**: Edit `config.toml` in container
- 💬 **CLI**: Access with `make shell`

---

**Happy tracking! 🎯**
