# Aver Docker Deployment Guide

Complete Docker containerization of the Aver record management system with web interface.

## 🐳 What's Included

This Docker setup packages:
- **aver.py** - The core record management backend
- **Web Interface** - PHP + Bootstrap 5 frontend
- **Apache Web Server** - Serves the application
- **SQLite Database** - Persistent data storage
- **Auto-initialization** - Automatically sets up database on first run

## 🚀 Quick Start

### Option 1: Docker Compose (Recommended)

```bash
# 1. Build and start the container
docker-compose up -d

# 2. Open your browser
open http://localhost:8080

# 3. Configure your user (first time only)
# Click "User Settings" and enter your handle and email
```

### Option 2: Docker CLI

```bash
# Build the image
docker build -t aver-web .

# Run the container
docker run -d \
  --name aver-web \
  -p 8080:80 \
  -v aver-data:/data \
  aver-web

# Open your browser
open http://localhost:8080
```

## 📦 Container Details

### Image Specifications
- **Base Image**: php:8.2-apache
- **Size**: ~400MB (approximate)
- **Architecture**: linux/amd64, linux/arm64

### Included Software
- Python 3.11+
- PHP 8.2 with Apache
- SQLite 3
- aver.py with all dependencies (PyYAML, tomli, tomli-w)

### Exposed Ports
- **80**: Web interface (mapped to 8080 on host by default)

### Volumes
- **/data**: Persistent storage for aver database
  - `/data/.aver/` - Aver database files
  - `/data/.aver/records/` - Markdown record files
  - `/data/.aver/db.sqlite` - SQLite index

## 🔧 Configuration

### Environment Variables

```yaml
# In docker-compose.yml
environment:
  - AVER_DB_PATH=/data/.aver          # Database location
  - PHP_UPLOAD_MAX_FILESIZE=10M       # Max file upload size
  - PHP_POST_MAX_SIZE=10M             # Max POST size
  - PHP_MAX_EXECUTION_TIME=300        # Script timeout (seconds)
  - TZ=America/Los_Angeles            # Timezone
```

### Custom Port Mapping

```yaml
# docker-compose.yml
ports:
  - "3000:80"  # Access at http://localhost:3000
```

### Using Your Own Database

```yaml
# docker-compose.yml
volumes:
  - ./my-aver-database:/data  # Mount your existing database
```

## 📊 Data Persistence

### Default Setup (Named Volume)
Data is stored in a Docker named volume `aver-data`:

```bash
# View volume info
docker volume inspect aver-data

# Backup the volume
docker run --rm -v aver-data:/data -v $(pwd):/backup ubuntu tar czf /backup/aver-backup.tar.gz /data

# Restore from backup
docker run --rm -v aver-data:/data -v $(pwd):/backup ubuntu tar xzf /backup/aver-backup.tar.gz -C /
```

### Bind Mount (Direct Access)
```yaml
# docker-compose.yml
volumes:
  - ./aver-data:/data  # Data in local directory
```

Now you can directly access files in `./aver-data/`

## 🛠️ Management Commands

### View Logs
```bash
docker-compose logs -f
# or
docker logs -f aver-web
```

### Access Container Shell
```bash
docker-compose exec aver-web bash
# or
docker exec -it aver-web bash
```

### Restart Container
```bash
docker-compose restart
# or
docker restart aver-web
```

### Stop Container
```bash
docker-compose down
# or
docker stop aver-web
```

### Rebuild After Changes
```bash
docker-compose down
docker-compose build --no-cache
docker-compose up -d
```

## 🔍 Using Aver CLI in Container

You can use the aver command-line interface inside the container:

```bash
# Access the container
docker exec -it aver-web bash

# Navigate to data directory
cd /data

# Use aver commands
aver record list
aver record new --title "Docker Test" --status open
aver record show REC-XXX
aver json io  # Start JSON IO mode

# Exit
exit
```

## 🎯 First-Time Setup

1. **Start the container**
   ```bash
   docker-compose up -d
   ```

2. **Access the web interface**
   - Open http://localhost:8080

3. **Configure user identity**
   - Click "User Settings" in the navbar
   - Enter your handle (e.g., "john.doe")
   - Enter your email (e.g., "john@example.com")
   - Click "Save Settings"

4. **Create your first record**
   - Click "Create Record" in the sidebar
   - Select a template (Default, bug_report, or feature_request)
   - Fill in the fields
   - Enter content
   - Click "Create Record"

5. **Explore features**
   - View all records
   - Search by field values
   - Add notes to records
   - Try different templates

## 🔐 Security Considerations

### Production Deployment

For production use, enhance security:

1. **Use HTTPS**
   ```yaml
   # docker-compose.yml
   services:
     aver-web:
       # ... existing config ...
       labels:
         - "traefik.enable=true"
         - "traefik.http.routers.aver.tls=true"
   ```

2. **Add Authentication**
   - Implement reverse proxy auth (nginx, Traefik)
   - Or add authentication to api.php

3. **Restrict Network Access**
   ```yaml
   # docker-compose.yml
   services:
     aver-web:
       networks:
         - internal
   networks:
     internal:
       internal: true
   ```

4. **Set Read-Only Root Filesystem**
   ```yaml
   # docker-compose.yml
   services:
     aver-web:
       read_only: true
       tmpfs:
         - /tmp
         - /var/run
         - /var/lib/php/sessions
   ```

### File Permissions

The container runs Apache as `www-data` user. Ensure proper permissions:

```bash
# If using bind mount
chmod -R 755 ./aver-data
chown -R 33:33 ./aver-data  # 33 = www-data UID/GID
```

## 🚢 Deployment Options

### Docker Hub
```bash
# Build and push
docker build -t yourusername/aver-web:latest .
docker push yourusername/aver-web:latest

# Pull and run
docker run -d -p 8080:80 -v aver-data:/data yourusername/aver-web:latest
```

### Kubernetes
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: aver-web
spec:
  replicas: 1
  selector:
    matchLabels:
      app: aver-web
  template:
    metadata:
      labels:
        app: aver-web
    spec:
      containers:
      - name: aver-web
        image: aver-web:latest
        ports:
        - containerPort: 80
        volumeMounts:
        - name: aver-data
          mountPath: /data
      volumes:
      - name: aver-data
        persistentVolumeClaim:
          claimName: aver-pvc
```

### Docker Swarm
```bash
docker stack deploy -c docker-compose.yml aver
```

## 🧪 Development Mode

### Hot Reload Development

```yaml
# docker-compose.dev.yml
version: '3.8'
services:
  aver-web:
    build: .
    ports:
      - "8080:80"
    volumes:
      - ./index.php:/var/www/html/index.php
      - ./api.php:/var/www/html/api.php
      - ./app.js:/var/www/html/app.js
      - aver-data:/data
    environment:
      - PHP_DISPLAY_ERRORS=On
      - PHP_ERROR_REPORTING=E_ALL
```

```bash
docker-compose -f docker-compose.dev.yml up
```

### Debug Mode

Access container with verbose logging:
```bash
docker-compose logs -f --tail=100
```

## 📈 Scaling

### Multiple Instances with Load Balancer

```yaml
# docker-compose.yml
version: '3.8'
services:
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
    depends_on:
      - aver-web-1
      - aver-web-2

  aver-web-1:
    build: .
    volumes:
      - aver-data:/data

  aver-web-2:
    build: .
    volumes:
      - aver-data:/data

volumes:
  aver-data:
```

**Note**: Shared database access requires file locking consideration.

## 🆘 Troubleshooting

### Container Won't Start
```bash
# Check logs
docker-compose logs

# Common issues:
# - Port 8080 already in use → Change port mapping
# - Permission denied → Check volume permissions
```

### Database Errors
```bash
# Reset database (WARNING: Deletes all data)
docker-compose down -v
docker-compose up -d

# Or backup and inspect:
docker run --rm -v aver-data:/data ubuntu ls -la /data/.aver
```

### Web Interface Not Loading
```bash
# Check container health
docker ps

# Check if Apache is running
docker exec aver-web ps aux | grep apache

# Test from inside container
docker exec aver-web curl http://localhost/
```

### Python/Aver Errors
```bash
# Test aver directly
docker exec -it aver-web bash
cd /data
aver --version
echo '{"command": "list-templates", "params": {}}' | aver json io
```

## 📚 Additional Resources

- **Aver Documentation**: See included markdown files
- **Docker Docs**: https://docs.docker.com
- **PHP Docker Image**: https://hub.docker.com/_/php
- **Bootstrap 5**: https://getbootstrap.com

## 🤝 Contributing

To modify the Docker setup:

1. Update Dockerfile or docker-compose.yml
2. Rebuild: `docker-compose build --no-cache`
3. Test: `docker-compose up`
4. Document changes in this README

## 📝 License

This Docker configuration follows the same license as aver.py.

---

## Quick Reference Card

```bash
# 🚀 Start
docker-compose up -d

# 📊 View Logs  
docker-compose logs -f

# 🛑 Stop
docker-compose down

# 🔄 Restart
docker-compose restart

# 🗑️ Reset (deletes data!)
docker-compose down -v

# 💾 Backup
docker run --rm -v aver-data:/data -v $(pwd):/backup ubuntu tar czf /backup/backup.tar.gz /data

# 📦 Restore
docker run --rm -v aver-data:/data -v $(pwd):/backup ubuntu tar xzf /backup/backup.tar.gz -C /

# 🔍 Shell Access
docker exec -it aver-web bash

# 🌐 Access
http://localhost:8080
```
