# Aver Web Interface

A complete, production-ready web interface for the Aver record management system.

[![Docker](https://img.shields.io/badge/docker-ready-blue.svg)](QUICKSTART_DOCKER.md)
[![Bootstrap](https://img.shields.io/badge/bootstrap-5.3-purple.svg)](https://getbootstrap.com)
[![PHP](https://img.shields.io/badge/php-8.2-777BB4.svg)](https://php.net)
[![Python](https://img.shields.io/badge/python-3.11+-3776AB.svg)](https://python.org)

## 🎯 What is This?

A modern, browser-based interface for managing records in Aver - complete with template support, dynamic forms, search capabilities, and a beautiful Bootstrap 5 UI. Everything is packaged in a Docker container for one-command deployment.

![Features](https://img.shields.io/badge/✨-Features-brightgreen)
- **📝 Dynamic Forms** - Fields auto-adjust based on selected template
- **🔍 Search & Filter** - Find records quickly by any field
- **📊 Template System** - Multiple record types with custom fields
- **👥 Multi-user** - Session-based user identity
- **⚡ Fast** - Persistent JSON IO connection to backend
- **🐳 Docker Ready** - Deploy in under 2 minutes

## 🚀 Quick Start Options

### Option 1: Docker (Recommended) 🐳

**Fastest way to get started:**

```bash
# Clone or download this repository
cd aver-web-interface

# Start the container
docker-compose up -d

# Open your browser
open http://localhost:8080
```

That's it! See [QUICKSTART_DOCKER.md](QUICKSTART_DOCKER.md) for details.

### Option 2: Manual Installation

**For custom deployments:**

```bash
# 1. Install aver.py
pip install pyyaml tomli tomli-w

# 2. Copy files to web directory
cp aver.py /usr/local/bin/aver
chmod +x /usr/local/bin/aver
cp index.php api.php app.js /var/www/html/aver/

# 3. Initialize aver database
cd /path/to/your/project
aver admin init

# 4. Start PHP server (development)
cd /var/www/html/aver
php -S localhost:8000

# 5. Open browser
open http://localhost:8000
```

See [README_WEB_INTERFACE.md](README_WEB_INTERFACE.md) for full manual installation guide.

## 📚 Documentation

| Document | Description |
|----------|-------------|
| [QUICKSTART_DOCKER.md](QUICKSTART_DOCKER.md) | 2-minute Docker setup guide |
| [DOCKER_README.md](DOCKER_README.md) | Complete Docker deployment guide |
| [README_WEB_INTERFACE.md](README_WEB_INTERFACE.md) | Manual installation & configuration |
| [JSON_IO_MODE_GUIDE.md](JSON_IO_MODE_GUIDE.md) | API reference for developers |
| [PACKAGE_SUMMARY.md](PACKAGE_SUMMARY.md) | Complete package overview |

## 🎨 Features

### Template-Driven Forms
```
Select Template → Form Fields Auto-Generate → Create Record
```
Fields automatically adjust based on your template configuration. No coding required.

### User Management
Simple session-based user identity. Set your handle and email once, and all records/notes are automatically attributed to you.

### Search & Filter
```
status=open → priority=high → component=auth
```
Flexible search syntax. Find exactly what you need.

### Notes & Collaboration
Add timestamped notes to any record. Perfect for tracking progress, discussions, or updates.

## 🏗️ Architecture

```
Browser (Bootstrap 5 UI)
    ↓ AJAX/Fetch
PHP Backend (api.php)
    ↓ JSON IO Protocol
aver.py (Python)
    ↓
SQLite + Markdown Files
```

**Key Components:**
- **Frontend**: Bootstrap 5 + Vanilla JavaScript
- **Backend**: PHP 8.2 with persistent aver connection
- **Storage**: SQLite index + Markdown content files
- **Container**: Docker with Apache web server

## 📦 What's Included

### Core Files
- `aver.py` - Enhanced with bug fixes and `list-templates` command
- `index.php` - Main web interface
- `api.php` - PHP backend API
- `app.js` - JavaScript frontend logic

### Docker Files
- `Dockerfile` - Container definition
- `docker-compose.yml` - Easy orchestration
- `init-aver.sh` - Auto-initialization
- `Makefile` - Convenient commands

### Configuration
- `example_config.toml` - Template examples
- Templates for: bugs, features, customer issues

## 🔧 Configuration

### Templates

Define custom record types in `.aver/config.toml`:

```toml
[template.bug_report]
record_prefix = "BUG"

[template.bug_report.record_special_fields]
[template.bug_report.record_special_fields.severity]
type = "single"
value_type = "string"
accepted_values = ["minor", "major", "critical", "blocker"]
required = true
```

### Custom Fields

Add any fields you need:
- **String fields**: text, dropdowns
- **Number fields**: integers, floats
- **Multi-value**: lists, tags
- **System values**: timestamps, usernames

See [example_config.toml](example_config.toml) for complete examples.

## 🎯 Use Cases

### Bug Tracking
- Multiple severity levels
- Component categorization
- Version tracking
- Resolution notes

### Feature Requests
- Category classification
- Effort estimation
- Requestor tracking
- Voting/prioritization

### Customer Support
- Account association
- Urgency levels
- Resolution time tracking
- Threaded conversations

### General Knowledge Base
- Document anything
- Categorize with custom fields
- Search and filter
- Collaborative notes

## 🛠️ Development

### Project Structure
```
aver-web-interface/
├── aver.py              # Backend (Python)
├── index.php            # Frontend HTML
├── api.php              # Backend API (PHP)
├── app.js               # Frontend Logic (JS)
├── Dockerfile           # Container definition
├── docker-compose.yml   # Container orchestration
├── init-aver.sh         # Initialization script
├── Makefile             # Convenience commands
└── docs/                # Documentation
```

### Making Changes

**Frontend (UI):**
```bash
# Edit index.php or app.js
# Refresh browser to see changes
```

**Backend (API):**
```bash
# Edit api.php
# Restart: docker-compose restart
```

**Aver Core:**
```bash
# Edit aver.py
# Rebuild: docker-compose build
```

### Testing

```bash
# Test aver directly
echo '{"command": "list-templates", "params": {}}' | aver json io

# Test API endpoint
curl "http://localhost:8080/api.php?action=list_templates"

# Test full stack
make test
```

## 🔐 Security

### Production Checklist

- [ ] Enable HTTPS/SSL
- [ ] Add authentication layer
- [ ] Configure CORS properly
- [ ] Set up rate limiting
- [ ] Regular backups
- [ ] Monitor logs
- [ ] Update dependencies
- [ ] Set resource limits

See [DOCKER_README.md](DOCKER_README.md#security-considerations) for details.

## 🐛 Troubleshooting

### Common Issues

**Container won't start:**
```bash
docker-compose logs
# Usually: port conflict or permission issue
```

**Database not initializing:**
```bash
docker exec -it aver-web bash
cd /data
aver admin init
```

**Web interface not loading:**
```bash
# Check container status
docker ps

# Check Apache
docker exec aver-web ps aux | grep apache
```

See [DOCKER_README.md](DOCKER_README.md#troubleshooting) for more solutions.

## 📊 Deployment Options

### Docker (Recommended)
```bash
docker-compose up -d
```

### Kubernetes
```yaml
apiVersion: apps/v1
kind: Deployment
# See DOCKER_README.md for full example
```

### Traditional Server
- Apache + PHP-FPM
- Nginx + PHP-FPM
- See README_WEB_INTERFACE.md

## 🤝 Contributing

Contributions welcome! Areas for improvement:
- Mobile responsiveness
- Rich text editor
- File attachments
- Advanced search
- Bulk operations
- Export formats
- Themes/customization

## 📄 License

This web interface follows the same license as aver.py.

## 🎓 Learn More

- **Aver Core**: Check aver.py documentation
- **JSON IO API**: See [JSON_IO_MODE_GUIDE.md](JSON_IO_MODE_GUIDE.md)
- **Templates**: See [example_config.toml](example_config.toml)
- **Docker**: See [DOCKER_README.md](DOCKER_README.md)

## 🆘 Support

- 📖 **Documentation**: See files listed above
- 🐛 **Issues**: Check logs and troubleshooting guides
- 💡 **Questions**: Review example configuration
- 🔧 **Custom Setup**: See manual installation guide

---

**Made with ❤️ for easier record management**

```
┌─────────────────────────────────────┐
│  Aver Web Interface                 │
│  ----------------------------------- │
│  ✨ Modern • Fast • Easy to Deploy  │
└─────────────────────────────────────┘
```
