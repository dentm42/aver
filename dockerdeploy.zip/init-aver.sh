#!/bin/bash
# init-aver.sh - Initialize aver database in Docker container

set -e

AVER_DB_PATH=${AVER_DB_PATH:-/data/.aver}

echo "Initializing Aver database at $AVER_DB_PATH..."

# Check if database already exists
if [ ! -f "$AVER_DB_PATH/db.sqlite" ]; then
    echo "No existing database found. Creating new aver database..."
    
    cd /data
    /usr/local/bin/aver admin init
    
    echo "Database initialized successfully!"
    
    # Create example config if none exists
    if [ ! -f "$AVER_DB_PATH/config.toml" ]; then
        echo "Creating example configuration..."
        cat > "$AVER_DB_PATH/config.toml" << 'EOF'
# Aver Configuration
default_record_prefix = "REC"
default_note_prefix = "NT"

[record_special_fields]

[record_special_fields.title]
type = "single"
value_type = "string"
editable = true
enabled = true
required = false

[record_special_fields.status]
type = "single"
value_type = "string"
editable = true
enabled = true
required = true
accepted_values = ["open", "in_progress", "resolved", "closed"]
default = "open"

[record_special_fields.priority]
type = "single"
value_type = "string"
editable = true
enabled = true
required = false
accepted_values = ["low", "medium", "high", "critical"]

[note_special_fields]

[note_special_fields.author]
type = "single"
value_type = "string"
editable = false
enabled = true
required = true
system_value = "user_name"

[note_special_fields.timestamp]
type = "single"
value_type = "string"
editable = false
enabled = true
required = true
system_value = "datetime"

[template.bug_report]
record_prefix = "BUG"

[template.bug_report.record_special_fields]

[template.bug_report.record_special_fields.severity]
type = "single"
value_type = "string"
editable = true
enabled = true
required = true
accepted_values = ["minor", "major", "critical", "blocker"]

[template.feature_request]
record_prefix = "FEAT"

[template.feature_request.record_special_fields]

[template.feature_request.record_special_fields.category]
type = "single"
value_type = "string"
editable = true
enabled = true
required = true
accepted_values = ["ui", "backend", "api", "documentation", "other"]
EOF
        echo "Example configuration created!"
    fi
else
    echo "Existing database found. Skipping initialization."
fi

# Set proper permissions
chown -R www-data:www-data "$AVER_DB_PATH"

echo "Aver initialization complete!"
